package my.assignment.applicationtwo;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private EditText pEtxt,rEtxt,payEtxt;
    private TextView baltxt,remtxt,inpaidtxt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        pEtxt=(EditText)findViewById(R.id.principalEtxt);
        rEtxt=(EditText)findViewById(R.id.rateEtxt);
        payEtxt=(EditText)findViewById(R.id.paymentEtxt);
        baltxt=(TextView)findViewById(R.id.lbl1);
        remtxt=(TextView)findViewById(R.id.lbl2);
        inpaidtxt=(TextView)findViewById(R.id.lbl3);
    }
    public void compute(View view){
        Log.i("Card Helper","Entered into compute method");
        if(pEtxt.getText().length()==0||rEtxt.getText().length()==0||payEtxt.getText().length()==0) {
            Toast.makeText(MainActivity.this, "Enter Values", Toast.LENGTH_SHORT).show();
            return;
        }


        int countMonth=0;
        double principal=0.0D;
        double rateperanum=0.0D;
        double minpayment=0.0d;
        double cardbal=0.0d;
        double interestpaid=0.0d;
        double totalinterest=0.0d;
        double principalpaid=0.0d;
        principal=Double.parseDouble(pEtxt.getText().toString());
        rateperanum=Double.parseDouble(rEtxt.getText().toString());
        minpayment=Double.parseDouble(payEtxt.getText().toString());
        cardbal=principal;
        Log.i("Card Helper",principal+" "+rateperanum+" "+minpayment+" "+cardbal);
        while (cardbal>0.0){
            countMonth++;
            if(cardbal==principalpaid ||cardbal<principalpaid) {
                break;
            }else{
            interestpaid=Math.round((cardbal*(rateperanum/(100*12))));
            totalinterest=totalinterest+interestpaid;
            principalpaid=minpayment-interestpaid;
            cardbal=cardbal-principalpaid;
            cardbal=Math.round(cardbal);
            }
            Log.i("Card Helper loop",principalpaid+" "+totalinterest+" "+interestpaid+" "+cardbal);

        }
        principal=principal+totalinterest;

        baltxt.setText(principal+"");
        remtxt.setText(countMonth+"");
        inpaidtxt.setText(totalinterest+"");


    }

    public void clear(View view){
        payEtxt.setText("");
        pEtxt.setText("");
        rEtxt.setText("");
        remtxt.setText("");
        baltxt.setText("");
        inpaidtxt.setText("");

    }
}
